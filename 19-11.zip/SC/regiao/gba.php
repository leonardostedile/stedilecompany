<!DOCTYPE html>
<html lang="pt-BR">


<!--Inicio Header-->

<head>
    <meta NAME="DESCRIPTION" CONTENT="Prazer me chamo Leonardo Stedile, sou corretor de imóveis na cidade de Brusque e Região,
    minha meta é transformar seu sonho emr realidade, trazendo as melhores ofertas do mercador imobiliário para você e sua família" />
    <meta NAME="ABSTRACT" CONTENT="Vou trazer as melhores ofertas do mercado imobiliário tanto para investimento quando para sua família!" />
    <meta name="keywords" content="Imobiliária, Corretor, Stedile, stedile, imóveis, imoveis, sucesso imóveis, imóveis em brusque, investimento, 
    envestimento, casas, apartamentos, casa geminada, casa germinada, imobiliária brusque, julio, julio imóveis, julio imoveis, Stédile, stédile, 
    terrenos, terenos, local, moresco, planifiki, minha casa minha vida, mcmv, envestmento, investimentos, vale do itajai, guabiruba, Guabiruba, GBA, gba,
    melhor local, condição de vida, cidade, municipio, município. " />
    <meta NAME="title" CONTENT="Stedile Imoveis | O melhor negócio é aqui." />
    <meta NAME="identifier-url" content="https://www.stedileimoveis.com/" />
    <meta NAME="author" content="Leonardo Stedile" />
    <meta NAME="ROBOTS" CONTENT="All" />
    <meta NAME="RATING" CONTENT="general" />
    <meta NAME="DISTRIBUTION" CONTENT="global" />
    <meta NAME="LANGUAGE" CONTENT="pt-br" />
    <meta name="content-language" content="portuguese" />
    <meta name="doc-class" content="Completed" />
    <meta name="reply-to" content="Leonardo Stedile" />

    <!-- Tags Para rede social Facebook -->
    <meta property="og:url" content="https://www.stedileimoveis.com/" />
    <meta property="og:locale" content="pt_BR" />
    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="Stedile Imóveis" />
    <meta property="og:title" content="Stedile Imoveis | O melhor negócio é aqui." />
    <meta property="og:description" content="Vou trazer as melhores ofertas do mercado imobiliário tanto para investimento tanto para lazer para você." />
    <meta property="og:image" content="" />
    <meta property="og:image:width" content="400" />
    <meta property="og:image:height" content="120" />
    <meta property="fb:app_id" content="" />

    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Corretor Leonardo Stedile</title>

    <!-- Favicon  -->
    <link rel="icon" href="../img/core-img/leo.png">

    <!-- Style CSS -->
    <link rel="stylesheet" href="../style.css">

</head>
<!--Fim Header-->

<body>

    <div id="preloader">
        <div class="south-load"></div>
    </div>

    <!-- Inico Header -->
    <header class="header-area">

        <!-- Top Header Area -->
        <div class="top-header-area">
            <div class="h-100 d-md-flex justify-content-between align-items-center">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div>
                        <ul class="classynav top-social-media pull-left">
                            <li>
                                <a href="mailto:corretorleonardostedile@gmail.com" target="_blank">corretorleonardostedile@gmail.com</a>
                            </li>

                        </ul>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="icones">
                        <ul class="classynav top-social-media pull-right">




                            <li>
                                <a href="https://www.instagram.com/leonardo.stedile/" target="_blank" title="Instagram" class="instagram"><i class="fa fa-instagram"></i></a>
                            </li>

                            <li>
                                <a href="https://www.facebook.com/leonardo.stedile.56/" target="_blank" title="Facebook" class="facebook"><i class="fa fa-facebook"></i></a>
                            </li>

                            <li>
                                <a href="https://www.youtube.com/channel/UCSdD7RHiLjyiP1YGJA0Keiw" target="_blank" class="youtube" title="Youtube" class="rss"><i class="fa fa-youtube-play"></i></a>
                            </li>

                            <li>
                                <a href="mailto:corretorleonardostedile@gmail.com" title="E-mail" class="rss"><i class="fa fa-envelope"></i></a>
                            </li>

                            <li>
                                <a href="https://api.whatsapp.com/send?1=pt_BR&amp;phone=5547992344339" target="_blank" class="wpp" title="Whatsapp" class="rss"><i class="fa fa-whatsapp"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>



            </div>
        </div>

        <!-- Main Header Area -->
        <div class="main-header-area" id="stickyHeader">
            <div class="classy-nav-container breakpoint-off">
                <!-- Classy Menu -->
                <nav class="classy-navbar justify-content-between" id="southNav">

                    <!-- Logo -->
                    <a class="nav-brand" href="../index.php"><img src="../img/core-img/logo1f.png" alt=""></a>

                    <!-- Navbar Toggler -->
                    <div class="classy-navbar-toggler">
                        <span class="navbarToggler"><span></span><span></span><span></span></span>
                    </div>

                    <!-- Menu -->
                    <div class="classy-menu">

                        <!-- close btn -->
                        <div class="classycloseIcon">
                            <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                        </div>

                        <!-- Nav Start -->
                        <div class="classynav">
                            <ul>
                                <li><a href="../menu/lançamentos.php">Lançamentos</a></li>
                                <li><a href="../menu/venda.php">venda</a></li>
                                <li><a href="../menu/locação.php">locação</a> </li>
                                <li><a href="#">Brusque e Região</a>
                                    <ul class="dropdown">
                                        <li><a class="menuu" href="../regiao/gba.php">Guabiruba</a></li>
                                        <li><a class="menuu" href="../regiao/bq.php">Brusque</a></li>
                                        <li><a class="menuu" href="../regiao/blumenau.php">Blumenau</a></li>
                                        <li><a class="menuu" href="../regiao/botuvera.php">Botuvera</a></li>
                                        <li><a class="menuu" href="../regiao/nt.php">Nova Trento</a></li>
                                        <li><a class="menuu" href="../regiao/sjb.php">São João Batista</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">Litoral</a>
                                    <ul class="dropdown">
                                        <li><a class="menuu" href="../litoral/balneariocamburiu.php">Balneário Camburiú</a></li>
                                        <li><a class="menuu" href="../litoral/camburiu.php">Camburiú </a></li>
                                        <li><a class="menuu" href="../litoral/gaspar.php">Gaspar</a></li>
                                        <li><a class="menuu" href="../litoral/itapema.php">Itapema</a></li>
                                        <li><a class="menuu" href="../litoral/portobelo.php">Porto Belo</a></li>
                                    </ul>
                                </li>
                                <li><a href="../menu/blog.php">Blog</a></li>
                                <li><a href="../menu/sobre.php">Sobre Nós</a></li>
                                <li><a href="../menu/contato.php">Contato</a></li>
                            </ul>

                            
                        </div>
                        
                    </div>
                </nav>
            </div>
        </div>
    </header>
    <!-- Fim Header -->


    <!--inico Banner-->
    <section class="breadcumb-area bg-img" style="background-image: url(../img/bg-img/gba.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcumb-content">
                        <h3 class="breadcumb-title">Guabiruba!</h3>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Fim Banner-->

    <!-- Inicio Propriedades Destaque-->
    <section class="featured-properties-area section-padding-100-50">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading wow fadeInUp">
                        <h2>Propriedades em Destaque</h2>
                        <p>O melhor lugar para você morar</p>
                    </div>
                </div>
            </div>




            <div class="row">

                <!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-50 wow fadeInUp" data-wow-delay="100ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb">

                            <img border-radius="50%" src="../img/imoveis/sitio/sitio0005.jpg" alt="" class="img">

                            <div class="tag">
                                <span>À venda</span>
                            </div>
                            <div class="list-price">
                                <p>R$ 450.000</p>
                            </div>
                        </div>
                        <!-- Property Content -->
                        <div class="property-content">
                            <h5>Sítio em Lageado Alto - Guabiruba</h5>
                            <p class="location"><img src="../img/icons/location.png" alt="">rua tal</p>
                            <p> Descrição imóvel...</p>
                            <div class="property-meta-data d-flex align-items-end justify-content-between">
                                <div class="new-tag">
                                    <img src="../img/icons/new.png" alt="">
                                </div>
                                <div class="bathroom">
                                    <img src="../img/icons/bathtub.png" alt="">
                                    <span>2</span>
                                </div>
                                <div class="garage">
                                    <img src="../img/icons/garage.png" alt="">
                                    <span>2</span>
                                </div>
                                <div class="space">
                                    <img src="../img/icons/space.png" alt="">
                                    <span>120 m²</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-50 wow fadeInUp" data-wow-delay="200ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb">

                            <img src="../img/teste/sala.jpeg" class="img">

                            <div class="tag">
                                <span>À venda</span>
                            </div>
                            <div class="list-price">
                                <p>R$ 250.000</p>
                            </div>
                        </div>
                        <!-- Property Content -->
                        <div class="property-content">
                            <h5>Centro, Brusque</h5>
                            <p class="location"><img src="../img/icons/location.png" alt="">Upper Road 3411, no.34 CA</p>
                            <p>Integer nec bibendum lacus. Suspendisse dictum enim sit amet libero malesuada.</p>
                            <div class="property-meta-data d-flex align-items-end justify-content-between">
                                <div class="new-tag">
                                    <img src="../img/icons/new.png" alt="">
                                </div>
                                <div class="bathroom">
                                    <img src="../img/icons/bathtub.png" alt="">
                                    <span>2</span>
                                </div>
                                <div class="garage">
                                    <img src="../img/icons/garage.png" alt="">
                                    <span>2</span>
                                </div>
                                <div class="space">
                                    <img src="../img/icons/space.png" alt="">
                                    <span>120 m²</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-50 wow fadeInUp" data-wow-delay="300ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb">
                            <img src="../img/teste/chandon.jpeg" class="img" alt="">

                            <div class="tag">
                                <span>À venda</span>
                            </div>
                            <div class="list-price">
                                <p>R$945.500</p>
                            </div>
                        </div>
                        <!-- Property Content -->
                        <div class="property-content">
                            <h5>Guabiruba</h5>
                            <p class="location"><img src="../img/icons/location.png" alt="">Upper Road 3411, no.34 CA</p>
                            <p>Integer nec bibendum lacus. Suspendisse dictum enim sit amet libero malesuada.</p>
                            <div class="property-meta-data d-flex align-items-end justify-content-between">
                                <div class="new-tag">
                                    <img src="../img/icons/new.png" alt="">
                                </div>
                                <div class="bathroom">
                                    <img src="../img/icons/bathtub.png" alt="">
                                    <span>2</span>
                                </div>
                                <div class="garage">
                                    <img src="../img/icons/garage.png" alt="">
                                    <span>2</span>
                                </div>
                                <div class="space">
                                    <img src="../img/icons/space.png" alt="">
                                    <span>120 m²</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-50 wow fadeInUp" data-wow-delay="400ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb">
                            <img src="../img/teste/001.jpeg" class="img" alt="">

                            <div class="tag">
                                <span>À venda</span>
                            </div>
                            <div class="list-price">
                                <p>R$350.900</p>
                            </div>
                        </div>
                        <!-- Property Content -->
                        <div class="property-content">
                            <h5>Blumenau</h5>
                            <p class="location"><img src="../img/icons/location.png" alt="">Upper Road 3411, no.34 CA</p>
                            <p>Integer nec bibendum lacus. Suspendisse dictum enim sit amet libero malesuada.</p>
                            <div class="property-meta-data d-flex align-items-end justify-content-between">
                                <div class="new-tag">
                                    <img src="../img/icons/new.png" alt="">
                                </div>
                                <div class="bathroom">
                                    <img src="../img/icons/bathtub.png" alt="">
                                    <span>2</span>
                                </div>
                                <div class="garage">
                                    <img src="../img/icons/garage.png" alt="">
                                    <span>2</span>
                                </div>
                                <div class="space">
                                    <img src="../img/icons/space.png" alt="">
                                    <span>120 m²</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-50 wow fadeInUp" data-wow-delay="500ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb">
                            <img src="../img/teste/hotel.jpg" class="img" alt="">

                            <div class="tag">
                                <span>À venda</span>
                            </div>
                            <div class="list-price">
                                <p>R$450.000</p>
                            </div>
                        </div>
                        <!-- Property Content -->
                        <div class="property-content">
                            <h5>Brusque</h5>
                            <p class="location"><img src="../img/icons/location.png" alt="">Upper Road 3411, no.34 CA</p>
                            <p>Integer nec bibendum lacus. Suspendisse dictum enim sit amet libero malesuada.</p>
                            <div class="property-meta-data d-flex align-items-end justify-content-between">
                                <div class="new-tag">
                                    <img src="../img/icons/new.png" alt="">
                                </div>
                                <div class="bathroom">
                                    <img src="../img/icons/bathtub.png" alt="">
                                    <span>2</span>
                                </div>
                                <div class="garage">
                                    <img src="../img/icons/garage.png" alt="">
                                    <span>2</span>
                                </div>
                                <div class="space">
                                    <img src="../img/icons/space.png" alt="">
                                    <span>120 m²</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-50 wow fadeInUp" data-wow-delay="600ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb">
                            <img src="../img/teste/00.jpg" class="img" alt="">

                            <div class="tag">
                                <span>À venda</span>
                            </div>
                            <div class="list-price">
                                <p>R$1.000.000</p>
                            </div>
                        </div>
                        <!-- Property Content -->
                        <div class="property-content">
                            <h5>Balneário Camboriú</h5>
                            <p class="location"><img src="../img/icons/location.png" alt="">Upper Road 3411, no.34 CA</p>
                            <p>Integer nec bibendum lacus. Suspendisse dictum enim sit amet libero malesuada.</p>
                            <div class="property-meta-data d-flex align-items-end justify-content-between">
                                <div class="new-tag">
                                    <img src="../img/icons/new.png" alt="">
                                </div>
                                <div class="bathroom">
                                    <img src="../img/icons/bathtub.png" alt="">
                                    <span>2</span>
                                </div>
                                <div class="garage">
                                    <img src="../img/icons/garage.png" alt="">
                                    <span>2</span>
                                </div>
                                <div class="space">
                                    <img src="../img/icons/space.png" alt="">
                                    <span>120 m²</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Fim Propriedades Destaque -->

    <!-- Inicio Frase em JS bonita -->
    <section class="call-to-action-area bg-fixed bg-overlay-black" style="background-image: url(../img/bg-img/cta.jpg)">
        <div class="container h-100">
            <div class="row align-items-center h-100">
                <div class="col-12">
                    <div class="cta-content text-center">
                        <h2 class="wow fadeInUp" data-wow-delay="300ms">O melhor lugar para você morar</h2>
                        <h6 class="wow fadeInUp" data-wow-delay="400ms">Os melhores imóveis de Brusque e região</h6>
                        <a href="#" class="btn south-btn mt-50 wow fadeInUp" data-wow-delay="500ms">Procurar</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Fim Frase em JS bonita -->

    <!-- Inicio Depoimento de nossos clientes -->
    <section class="south-testimonials-area section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading wow fadeInUp" data-wow-delay="250ms">
                        <h2>Depoimentos de Clientes</h2>
                        <p>Nossa equipe trabalha para trazer os melhores imóveis para sua família</p>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="testimonials-slides owl-carousel wow fadeInUp" data-wow-delay="500ms">

                        <!-- Single Testimonial Slide -->
                        <div class="single-testimonial-slide text-center">
                            <h5>Perfect Home for me</h5>
                            <p>Etiam nec odio vestibulum est mattis effic iturut magna. Pellentesque sit amet tellus blandit. Etiam nec odio vestibulum est mattis effic iturut magna. Pellentesque sit am et tellus blandit. Etiam nec odio vestibul. Etiam nec odio vestibulum est mat tis effic iturut magna.</p>

                            <div class="testimonial-author-info">
                                <img src="../img/bg-img/feature6.jpg" alt="">
                                <p>Daiane Smith, <span>Customer</span></p>
                            </div>
                        </div>

                        <!-- Single Testimonial Slide -->
                        <div class="single-testimonial-slide text-center">
                            <h5>Perfect Home for me</h5>
                            <p>Etiam nec odio vestibulum est mattis effic iturut magna. Pellentesque sit amet tellus blandit. Etiam nec odio vestibulum est mattis effic iturut magna. Pellentesque sit am et tellus blandit. Etiam nec odio vestibul. Etiam nec odio vestibulum est mat tis effic iturut magna.</p>

                            <div class="testimonial-author-info">
                                <img src="../img/bg-img/feature6.jpg" alt="">
                                <p>Daiane Smith, <span>Customer</span></p>
                            </div>
                        </div>

                        <!-- Single Testimonial Slide -->
                        <div class="single-testimonial-slide text-center">
                            <h5>Perfect Home for me</h5>
                            <p>Etiam nec odio vestibulum est mattis effic iturut magna. Pellentesque sit amet tellus blandit. Etiam nec odio vestibulum est mattis effic iturut magna. Pellentesque sit am et tellus blandit. Etiam nec odio vestibul. Etiam nec odio vestibulum est mat tis effic iturut magna.</p>

                            <div class="testimonial-author-info">
                                <img src="../img/bg-img/feature6.jpg" alt="">
                                <p>Daiane Smith, <span>Customer</span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Fim Depoimento de nossos clientes -->

    <!-- Inicio Biografia -->
    <section class="south-editor-area d-flex align-items-center">
        <!-- Editor Content -->
        <div class="editor-content-area">
            <!-- Section Heading -->
            <div class="section-heading wow fadeInUp" data-wow-delay="250ms">
                <img src="../img/icons/prize.png" alt="">
                <h2>Leonardo Stedile</h2>
                <p>Corretor de imóveis</p>
            </div>
            <p class="wow fadeInUp" data-wow-delay="500ms">Prazer me chamo Leonado Stedile, sou Corretor de Imóveis autônomo,
                seja muito bem vindo no meu site, aqui voce pode encontrar os melhores imóveis de Brusque e região e
                também vendo imóveis na praia, caso se interesse entre em contato comigo!</p>

            <div class="address wow fadeInUp" data-wow-delay="800ms">
                <h6><img src="../img/icons/phone-call.png" alt="">

                    <a class="meio" href="https://api.whatsapp.com/send?1=pt_BR&phone=5547992344339">
                        +55 (47)99234-4339 </a>
                </h6>

                <h6><img src="../img/icons/envelope.png" alt=""><a class="meio" href="mailto:corretorleonardostedile@gmail.com">
                        corretorleonardostedile@gmail.com</a></h6>
            </div>
            <div class="signature mt-50 wow fadeInUp" data-wow-delay="1000ms">
                <img src="../img/core-img/signature.png" alt="">
            </div>
        </div>

        <!-- Editor Thumbnail -->
        <div class="editor-thumbnail">
            <img src="../img/teste/leo.png" alt="">
        </div>
    </section>
    <!-- Fim Biografia -->

  <!-- Inicio Footer -->
  <footer class="footer-area section-padding-100-0 bg-img gradient-background-overlay" style="background-image: url(../img/bg-img/cta.jpg);">
        <!-- Main Footer Area -->
        <div class="main-footer-area">
            <div class="container">
                <div class="row">

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-xl-4">
                        <div class="footer-widget-area mb-100">
                            <!-- Widget Title -->
                            <div class="widget-title">
                                <h6>Fale conosco</h6>
                            </div>


                            <div class="footer-logo my-4">
                                <img src="../img/core-img/logo1f.png" alt="">
                            </div>
                            <ul class="final">

                                <li>
                                    Endereço: R. Hilário EBel, 41 - Lageado Baixo, Guabiruba - SC, 88360-000
                                </li>
                                <li>
                                    Email: <a class="final" href="mailto:corretorleonardostedile@gmail.com">
                                        corretorleonardostedile@gmail.com </a>
                                </li>
                                <li>
                                    Fone: <a class="final" href="tel:(47) 3308-8977">
                                        (47) 3308-8977 </a>
                                </li>
                                <li>
                                    Whats:
                                    <a class="final" href="https://api.whatsapp.com/send?1=pt_BR&phone=5547992344339">
                                        (47) 99234-4339 </a>


                                </li>


                                <li>
                                    <h4><br /> CRECI: #### </h4>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-xl-4">
                        <div class="footer-widget-area mb-100">
                            <!-- Widget Title -->
                            <div class="widget-title">
                                <h6>Horários</h6>
                            </div>
                            <!-- Office Hours -->
                            <div class="weekly-office-hours">
                                <ul>
                                    <li class="d-flex align-items-center justify-content-between"><span>Segunda - Sexta </span> <span>09:00 ás 19:00</span></li>
                                    <li class="d-flex align-items-center justify-content-between"><span>Sábado</span> <span>09:00 ás 14:00</span></li>
                                    <li class="d-flex align-items-center justify-content-between"><span>Domingo</span> <span>Fechado</span></li>
                                </ul>
                            </div>
                            <!-- Address -->
                            <div class="address">
                                <h6><img src="../img/icons/phone-call.png" alt=""> +55 (47) 99234-4339</h6>
                                <h6><img src="../img/icons/envelope.png" alt=""> corretorleonardostedile@gmail.com</h6>
                                <h6><img src="../img/icons/location.png" alt=""> Rua Hilário Ebel, Nº 41, Lageado Baixo, Guabiruba, SC</h6>
                            </div>
                        </div>
                    </div>

                    <!-- Single Footer Widget -->


                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-xl-4">
                        <div class="footer-widget-area mb-100">
                            <!-- Widget Title -->
                            <div class="widget-title">
                                <h6>
                                    Propriedades em destaque</h6>
                            </div>
                            <!-- Featured Properties Slides -->
                            <div class="featured-properties-slides owl-carousel">
                                <!-- Single Slide -->
                                <div class="single-featured-properties-slide">
                                    <a href="#"><img src="../img/bg-img/fea-product.jpg" alt=""></a>
                                </div>
                                <!-- Single Slide -->
                                <div class="single-featured-properties-slide">
                                    <a href="#"><img src="../img/bg-img/fea-product.jpg" alt=""></a>
                                </div>
                                <!-- Single Slide -->
                                <div class="single-featured-properties-slide">
                                    <a href="#"><img src="../img/bg-img/fea-product.jpg" alt=""></a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- Inicio Copywrite  -->
        <div class="copywrite-text d-flex align-items-center justify-content-center">
            <a href="../index.php">
                <font color="white">

                    Copyright © 2021| Corretor Leonardo Stedile

            </a>
        </div>
        <!-- Fim Copywrite  -->

        </footer>
    <!-- Fim footer -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="../js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="../js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="../js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="../js/plugins.js"></script>
    <script src="../js/classy-nav.min.js"></script>
    <script src="../js/jquery-ui.min.js"></script>
    <!-- Active js -->
    <script src="../js/active.js"></script>

</body>

</html>